
#include "nodes.hpp"
#include <numeric>
#include <utility>
#include "iterator"
Time Worker::t_ = 0;

//ReceiverPreferences::ReceiverPreferences(ProbabilityGenerator probability_function) {
//    preferences_t m;
//    preferences_ = m;
//    rand_function = std::move(probability_function);
//}

//void ReceiverPreferences::add_receiver(IPackageReceiver * r) {
//    preferences_.insert(std::pair<IPackageReceiver*, double>(r, probability_));
//    for(auto & el : preferences_) {
//        el.second = 1.0 / preferences_.size();
//    }
//}

void ReceiverPreferences::add_receiver(IPackageReceiver * r) {

    int size = preferences_.size();
    size ++;
    double step = 1/size;

    for (auto &it : preferences_) {

        it.second = step;
        step += step;
    }

    preferences_.insert(std::pair<IPackageReceiver*, double>(r, 1));
}

void ReceiverPreferences::remove_receiver(IPackageReceiver * r) {

    if(preferences_.count(r)) {
        preferences_.erase(r);

        for (auto &it: preferences_) {
            it.second = 1.0 / preferences_.size();
        }
    }
}


IPackageReceiver* ReceiverPreferences::choose_receiver() {

    IPackageReceiver *receiver = nullptr;

    double sum = 0;

    for(auto it: preferences_){
        sum += it.second;
        if(probability_ < sum)
            return it.first;
    }

    return receiver;
}

void PackageSender::send_package() {

    if(sending_buffer_.has_value()){
        IPackageReceiver* receiver = receiver_preferences_.choose_receiver();
        receiver->receive_package(std::move(sending_buffer_.value()));
        sending_buffer_.reset();
    }
}


void Ramp::deliver_goods(Time t) {

    if (std::fmod(t - 1 ,di_) == 0){

        Package Pac (id_);
        push_package(std::move(Pac));
    };
}


void Worker::do_work(Time t) {
    if(t_ == 0 && !q_->empty()) {
        t_ = t;
        package_to_buf(q_->pop());
    }
    if(t - t_ == pd_ - 1){
        push_package(std::move(buf.value()));
        t_ = 0;
        buf.reset();
        if(!q_->empty()) {
            t_ = t;
            package_to_buf(q_->pop());
        }
    }
//
//void Worker::do_work(Time t) {
//
//    if (work_time == 0){
//        start_time_ = t;
//    }
//
//
//    if (work_time == pd_){
//
//        Package Pac (id_);
//        push_package(std::move(Pac));
//        work_time = 0;
//    }
//    else{
//        work_time++;
//    }

}
