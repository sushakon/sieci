# NetSim
Symulacja sieci (C++)

1. iterator w storage_types
2. choose_receiver